"""
auth.py
=======
Système d'authentification pour l'application CIE

Gestion des utilisateurs avec fichier Excel crypté
"""

import pandas as pd
import hashlib
import os
import streamlit as st
from datetime import datetime, timedelta

# Fichier des utilisateurs
FICHIER_USERS = "users.xlsx"

# Clé secrète pour les sessions (à changer en production)
SECRET_KEY = "cie_secret_key_2025"


def hash_password(password):
    """Hash un mot de passe avec SHA-256"""
    return hashlib.sha256(f"{password}{SECRET_KEY}".encode()).hexdigest()


def init_users_file():
    """Initialise le fichier utilisateurs avec un admin par défaut"""
    if not os.path.exists(FICHIER_USERS):
        # Créer admin par défaut
        df_users = pd.DataFrame({
            'username': ['admin'],
            'password': [hash_password('admin123')],
            'nom': ['Administrateur'],
            'role': ['admin'],
            'actif': [True],
            'created_at': [datetime.now()],
            'last_login': [None]
        })
        df_users.to_excel(FICHIER_USERS, index=False)
        return True
    return False


def charger_users():
    """Charge la liste des utilisateurs"""
    if not os.path.exists(FICHIER_USERS):
        init_users_file()
    return pd.read_excel(FICHIER_USERS)


def sauvegarder_users(df):
    """Sauvegarde la liste des utilisateurs"""
    df.to_excel(FICHIER_USERS, index=False)


def authentifier(username, password):
    """
    Authentifie un utilisateur
    
    Returns:
        dict: Info utilisateur si authentifié, None sinon
    """
    df_users = charger_users()
    
    # Chercher l'utilisateur
    user = df_users[df_users['username'] == username]
    
    if user.empty:
        return None
    
    user = user.iloc[0]
    
    # Vérifier mot de passe
    if user['password'] != hash_password(password):
        return None
    
    # Vérifier si actif
    if not user['actif']:
        return None
    
    # Mettre à jour last_login
    df_users.loc[df_users['username'] == username, 'last_login'] = datetime.now()
    sauvegarder_users(df_users)
    
    return {
        'username': user['username'],
        'nom': user['nom'],
        'role': user['role']
    }


def ajouter_utilisateur(username, password, nom, role='utilisateur'):
    """
    Ajoute un nouvel utilisateur
    
    Args:
        username: Nom d'utilisateur unique
        password: Mot de passe
        nom: Nom complet
        role: 'admin' ou 'utilisateur'
    
    Returns:
        bool: True si ajouté, False si username existe déjà
    """
    df_users = charger_users()
    
    # Vérifier si username existe
    if username in df_users['username'].values:
        return False
    
    # Ajouter
    nouveau_user = pd.DataFrame({
        'username': [username],
        'password': [hash_password(password)],
        'nom': [nom],
        'role': [role],
        'actif': [True],
        'created_at': [datetime.now()],
        'last_login': [None]
    })
    
    df_users = pd.concat([df_users, nouveau_user], ignore_index=True)
    sauvegarder_users(df_users)
    
    return True


def modifier_password(username, nouveau_password):
    """Modifie le mot de passe d'un utilisateur"""
    df_users = charger_users()
    
    if username not in df_users['username'].values:
        return False
    
    df_users.loc[df_users['username'] == username, 'password'] = hash_password(nouveau_password)
    sauvegarder_users(df_users)
    
    return True


def desactiver_utilisateur(username):
    """Désactive un utilisateur"""
    df_users = charger_users()
    
    if username not in df_users['username'].values:
        return False
    
    df_users.loc[df_users['username'] == username, 'actif'] = False
    sauvegarder_users(df_users)
    
    return True


def activer_utilisateur(username):
    """Active un utilisateur"""
    df_users = charger_users()
    
    if username not in df_users['username'].values:
        return False
    
    df_users.loc[df_users['username'] == username, 'actif'] = True
    sauvegarder_users(df_users)
    
    return True


def verifier_session():
    """
    Vérifie si l'utilisateur est connecté
    
    Returns:
        bool: True si connecté, False sinon
    """
    return 'user' in st.session_state and st.session_state.user is not None


def get_user_info():
    """
    Récupère les infos de l'utilisateur connecté
    
    Returns:
        dict: Info utilisateur ou None
    """
    if verifier_session():
        return st.session_state.user
    return None


def est_admin():
    """Vérifie si l'utilisateur connecté est admin"""
    user = get_user_info()
    if user:
        return user['role'] == 'admin'
    return False


def deconnecter():
    """Déconnecte l'utilisateur"""
    if 'user' in st.session_state:
        st.session_state.user = None
    st.rerun()


def page_connexion():
    """Page de connexion Streamlit"""
    
    # Centrer le contenu
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("""
        <div style='text-align: center; padding: 2rem 0;'>
            <h1>⚡ Gestion Factures CIE</h1>
            <p style='color: #666;'>Connexion requise</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Formulaire de connexion
        with st.form("login_form"):
            username = st.text_input("👤 Nom d'utilisateur", key="login_username")
            password = st.text_input("🔒 Mot de passe", type="password", key="login_password")
            
            submitted = st.form_submit_button("🚀 Se connecter", use_container_width=True, type="primary")
            
            if submitted:
                if not username or not password:
                    st.error("❌ Veuillez remplir tous les champs")
                else:
                    user = authentifier(username, password)
                    
                    if user:
                        st.session_state.user = user
                        st.success(f"✅ Bienvenue {user['nom']} !")
                        st.rerun()
                    else:
                        st.error("❌ Identifiants incorrects")
        
        # Info par défaut
        with st.expander("ℹ️ Première connexion"):
            st.info("""
            **Compte par défaut :**
            - Utilisateur : `admin`
            - Mot de passe : `admin123`
            
            ⚠️ Changez ce mot de passe après votre première connexion !
            """)


def page_gestion_users():
    """Page de gestion des utilisateurs (admin uniquement)"""
    
    if not est_admin():
        st.error("❌ Accès réservé aux administrateurs")
        return
    
    st.header("👥 Gestion des Utilisateurs")
    
    df_users = charger_users()
    
    # Statistiques
    col1, col2, col3 = st.columns(3)
    col1.metric("Total utilisateurs", len(df_users))
    col2.metric("Actifs", len(df_users[df_users['actif'] == True]))
    col3.metric("Admins", len(df_users[df_users['role'] == 'admin']))
    
    st.markdown("---")
    
    # Tabs
    tab1, tab2, tab3 = st.tabs(["📋 Liste", "➕ Ajouter", "🔧 Modifier"])
    
    # --- TAB 1 : Liste ---
    with tab1:
        st.subheader("Liste des utilisateurs")
        
        # Afficher sans le mot de passe
        df_display = df_users[['username', 'nom', 'role', 'actif', 'created_at', 'last_login']].copy()
        
        st.dataframe(
            df_display,
            use_container_width=True,
            column_config={
                "username": "Utilisateur",
                "nom": "Nom complet",
                "role": st.column_config.SelectboxColumn(
                    "Rôle",
                    options=["admin", "utilisateur"]
                ),
                "actif": st.column_config.CheckboxColumn("Actif"),
                "created_at": st.column_config.DatetimeColumn("Créé le"),
                "last_login": st.column_config.DatetimeColumn("Dernière connexion")
            }
        )
    
    # --- TAB 2 : Ajouter ---
    with tab2:
        st.subheader("Ajouter un utilisateur")
        
        with st.form("add_user_form"):
            new_username = st.text_input("Nom d'utilisateur")
            new_nom = st.text_input("Nom complet")
            new_password = st.text_input("Mot de passe", type="password")
            new_password_confirm = st.text_input("Confirmer mot de passe", type="password")
            new_role = st.selectbox("Rôle", ["utilisateur", "admin"])
            
            submitted = st.form_submit_button("➕ Ajouter", type="primary")
            
            if submitted:
                if not all([new_username, new_nom, new_password]):
                    st.error("❌ Tous les champs sont requis")
                elif new_password != new_password_confirm:
                    st.error("❌ Les mots de passe ne correspondent pas")
                elif len(new_password) < 6:
                    st.error("❌ Le mot de passe doit contenir au moins 6 caractères")
                else:
                    if ajouter_utilisateur(new_username, new_password, new_nom, new_role):
                        st.success(f"✅ Utilisateur {new_username} ajouté !")
                        st.rerun()
                    else:
                        st.error("❌ Ce nom d'utilisateur existe déjà")
    
    # --- TAB 3 : Modifier ---
    with tab3:
        st.subheader("Modifier un utilisateur")
        
        usernames = df_users['username'].tolist()
        selected_user = st.selectbox("Sélectionner un utilisateur", usernames)
        
        if selected_user:
            col_a, col_b = st.columns(2)
            
            with col_a:
                st.markdown("#### 🔒 Changer mot de passe")
                with st.form("change_password_form"):
                    new_pwd = st.text_input("Nouveau mot de passe", type="password", key="new_pwd")
                    new_pwd_confirm = st.text_input("Confirmer", type="password", key="new_pwd_confirm")
                    
                    if st.form_submit_button("Changer"):
                        if new_pwd != new_pwd_confirm:
                            st.error("❌ Mots de passe différents")
                        elif len(new_pwd) < 6:
                            st.error("❌ Minimum 6 caractères")
                        else:
                            modifier_password(selected_user, new_pwd)
                            st.success("✅ Mot de passe modifié !")
            
            with col_b:
                st.markdown("#### 🔄 Activer/Désactiver")
                user_info = df_users[df_users['username'] == selected_user].iloc[0]
                
                if user_info['actif']:
                    if st.button("🔴 Désactiver", use_container_width=True):
                        desactiver_utilisateur(selected_user)
                        st.success(f"✅ {selected_user} désactivé")
                        st.rerun()
                else:
                    if st.button("🟢 Activer", use_container_width=True):
                        activer_utilisateur(selected_user)
                        st.success(f"✅ {selected_user} activé")
                        st.rerun()


def afficher_user_info():
    """Affiche les infos de l'utilisateur connecté dans la sidebar"""
    user = get_user_info()
    
    if user:
        st.sidebar.markdown("---")
        st.sidebar.markdown(f"### 👤 {user['nom']}")
        st.sidebar.caption(f"@{user['username']} • {user['role']}")
        
        if st.sidebar.button("🚪 Déconnexion", use_container_width=True):
            deconnecter()
