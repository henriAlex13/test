# 🔐 Guide : Système de Connexion

## ✅ **Installation Terminée !**

Ton application dispose maintenant d'un **système de connexion sécurisé**.

---

## 🚀 **Premier démarrage**

### 1. Lancer l'application

```bash
streamlit run app.py
```

### 2. Page de connexion

Tu verras la page de connexion :

```
⚡ CIE - Connexion
───────────────────
👤 Nom d'utilisateur : [_______]
🔒 Mot de passe      : [_______]

[🚀 Se connecter] [ℹ️ Aide]
```

### 3. Première connexion

**Compte administrateur par défaut :**
- **Username** : `admin`
- **Password** : `admin123`

⚠️ **IMPORTANT : Change ce mot de passe immédiatement après !**

---

## 👥 **Gestion des utilisateurs**

### Menu Admin (visible uniquement si Admin)

Après connexion en tant qu'admin, tu verras dans le menu :
```
📋 Navigation
───────────────
📊 Base Centrale
📋 Non Enregistrées
🔄 Import Factures BT
🔄 Import Factures HT
📈 Statistiques
⚙️ Génération Fichiers
👥 Gestion Utilisateurs  ← NOUVEAU
```

### Page Gestion Utilisateurs

3 onglets disponibles :

#### 📋 **Onglet Liste**

Affiche tous les utilisateurs :
```
┌────────────┬─────────────┬───────┬───────┬────────────┐
│ Username   │ Nom complet │ Rôle  │ Actif │ Créé le    │
├────────────┼─────────────┼───────┼───────┼────────────┤
│ admin      │ Administra. │ Admin │ ✓     │ 02/02/2026 │
│ comptable  │ Marie Koffi │ User  │ ✓     │ 02/02/2026 │
│ ancien_user│ Jean Konan  │ User  │ ✗     │ 01/01/2026 │
└────────────┴─────────────┴───────┴───────┴────────────┘
```

**Actions disponibles :**
- **Désactiver** : Empêche un utilisateur de se connecter (sans supprimer)
- **Réactiver** : Réactive un compte désactivé

#### ➕ **Onglet Ajouter**

Créer un nouvel utilisateur :
```
Nom d'utilisateur  : [_________]
Nom complet        : [_________]
Mot de passe       : [_________]
Confirmer MDP      : [_________]
Rôle               : [User ▼] ou [Admin ▼]

[➕ Ajouter l'utilisateur]
```

**Règles :**
- Username unique
- Mot de passe minimum 6 caractères
- Confirmation obligatoire

#### 🔑 **Onglet Changer MDP**

Modifier le mot de passe d'un utilisateur :
```
Utilisateur       : [Sélectionner ▼]
Nouveau MDP       : [_________]
Confirmer         : [_________]

[🔑 Changer le mot de passe]
```

---

## 🔒 **Sécurité**

### Mots de passe

✅ **Hashés avec SHA-256**
- Les mots de passe ne sont jamais stockés en clair
- Impossible de récupérer le mot de passe original
- Même l'admin ne peut pas voir les mots de passe

### Fichier users.xlsx

Structure :
```
┌──────────┬──────────────────┬─────────────┬───────┬───────┬────────────┐
│ username │ password_hash    │ nom_complet │ role  │ actif │ created_at │
├──────────┼──────────────────┼─────────────┼───────┼───────┼────────────┤
│ admin    │ 8c6976e5b541...  │ Administra. │ Admin │ True  │ 2026-02-02 │
└──────────┴──────────────────┴─────────────┴───────┴───────┴────────────┘
```

⚠️ **Ne pas modifier ce fichier manuellement !** Utilise l'interface.

---

## 👤 **Rôles et permissions**

### **Role : Admin**

✅ Accès complet :
- Toutes les pages de l'application
- Gestion des utilisateurs
- Ajouter/désactiver des comptes
- Changer les mots de passe

### **Role : User**

✅ Accès limité :
- Toutes les pages de l'application
- SAUF "Gestion Utilisateurs"
- Peut utiliser toutes les fonctionnalités normales

---

## 🔄 **Workflow type**

### Scénario 1 : Ajouter un utilisateur

```
1. Connexion en tant qu'admin
2. Menu → "👥 Gestion Utilisateurs"
3. Onglet "➕ Ajouter"
4. Remplir le formulaire
5. Cliquer "Ajouter"
6. ✅ Nouvel utilisateur créé !
```

### Scénario 2 : Employé quitte l'entreprise

```
1. Menu → "👥 Gestion Utilisateurs"
2. Onglet "📋 Liste"
3. Section "Désactiver un utilisateur"
4. Sélectionner l'employé
5. Cliquer "🔒 Désactiver"
6. ✅ Le compte est bloqué (historique conservé)
```

### Scénario 3 : Mot de passe oublié

```
1. Admin se connecte
2. Menu → "👥 Gestion Utilisateurs"
3. Onglet "🔑 Changer MDP"
4. Sélectionner l'utilisateur
5. Entrer nouveau mot de passe
6. ✅ MDP réinitialisé !
```

### Scénario 4 : Changer son propre mot de passe

```
1. Demander à l'admin
   (L'admin peut changer n'importe quel MDP)
```

---

## 📊 **Interface utilisateur**

### Sidebar (après connexion)

```
📋 Navigation
───────────────
[Menu...]

📊 Informations
───────────────
📝 Lignes : 247
📅 Périodes : 3

👤 Utilisateur
───────────────
Marie Koffi
Role: User

[🚪 Déconnexion]
```

### Bouton Déconnexion

- Visible dans la sidebar
- Un clic → Retour à la page de connexion
- Session effacée

---

## 🛡️ **Bonnes pratiques**

### Pour l'Admin

✅ **À FAIRE :**
1. Changer le mot de passe `admin` **immédiatement**
2. Créer un compte utilisateur normal pour toi
3. Ne donner le compte admin qu'aux personnes de confiance
4. Désactiver les anciens comptes (ne pas supprimer)
5. Utiliser des mots de passe forts (min 8 caractères)

❌ **NE PAS FAIRE :**
1. Partager le mot de passe admin
2. Modifier `users.xlsx` manuellement
3. Supprimer le compte admin
4. Utiliser des mots de passe faibles

### Pour les Utilisateurs

✅ **À FAIRE :**
1. Noter son mot de passe en lieu sûr
2. Ne pas partager ses identifiants
3. Se déconnecter après utilisation

❌ **NE PAS FAIRE :**
1. Laisser sa session ouverte
2. Partager son compte
3. Utiliser le même mot de passe partout

---

## 🔧 **Dépannage**

### Problème : "Impossible de se connecter"

**Causes possibles :**
1. Mot de passe incorrect
2. Compte désactivé
3. Username inexistant

**Solutions :**
1. Vérifier username/password
2. Contacter admin pour réactivation
3. Contacter admin pour créer compte

### Problème : "Fichier users.xlsx corrompu"

**Solution :**
1. Supprimer `users.xlsx`
2. Relancer l'app
3. ✅ Fichier recréé avec compte admin par défaut

### Problème : "J'ai oublié le mot de passe admin"

**Solution d'urgence :**
1. Supprimer `users.xlsx`
2. Relancer l'app
3. ✅ Compte admin/admin123 recréé
4. ⚠️ TOUS les autres utilisateurs sont perdus !

**Meilleure solution :**
1. Faire une copie régulière de `users.xlsx`
2. Restaurer la copie si problème

---

## 📁 **Fichiers**

### Structure

```
projet/
├── app.py              # Application principale
├── auth.py             # Module authentification ✨
├── models.py
├── import_bt.py
├── import_ht.py
├── generation.py
├── non_enregistrees.py
├── users.xlsx          # Base utilisateurs ✨
├── data_centrale.pkl
└── Base_Centrale.xlsx
```

### Fichiers importants

**users.xlsx** : Base des utilisateurs
- ✅ Sauvegarder régulièrement
- ❌ Ne pas partager (contient les hashs)
- 🔐 Garder en sécurité

---

## 🎯 **Cas d'usage**

### Cas 1 : Petite équipe (2-3 personnes)

```
Users :
- admin (toi)
- comptable1 (User)
- comptable2 (User)

Tous peuvent utiliser l'app, seul admin gère les comptes.
```

### Cas 2 : Rotation du personnel

```
Nouvel employé :
→ Admin crée compte

Départ employé :
→ Admin désactive (historique conservé)

Retour employé :
→ Admin réactive
```

### Cas 3 : Audit

```
Besoin de savoir qui a fait quoi ?
→ Regarde users.xlsx : last_login, created_at
→ Chaque user a son propre compte
→ Traçabilité assurée
```

---

## ✅ **Checklist première utilisation**

```
[ ] Lancer l'app
[ ] Se connecter avec admin/admin123
[ ] Aller dans "👥 Gestion Utilisateurs"
[ ] Changer le mot de passe admin
[ ] Créer compte(s) pour utilisateur(s)
[ ] Tester connexion avec nouveau compte
[ ] Se déconnecter
[ ] ✅ Système opérationnel !
```

---

## 🚀 **Prochaines étapes (optionnel)**

### Améliorations possibles

1. **Sessions avec expiration**
   - Déconnexion auto après 1h

2. **Logs d'activité**
   - Qui a fait quoi et quand

3. **Récupération mot de passe**
   - Par email (nécessite config SMTP)

4. **Niveau de permissions**
   - Lecture seule
   - Import uniquement
   - Génération uniquement

5. **2FA (Two-Factor Authentication)**
   - Code SMS ou app

**Pour l'instant : Le système actuel est largement suffisant ! 🎯**

---

## 📞 **Support**

Si problème :
1. Vérifier ce guide
2. Tester avec compte admin par défaut
3. Supprimer users.xlsx en dernier recours

**Le système de connexion est maintenant actif ! 🔐✨**
