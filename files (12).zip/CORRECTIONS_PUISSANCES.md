# 🔧 Corrections - Récupération des Puissances (PSABON et PSATTEINTE)

## 📋 Problème identifié

Les colonnes **PSABON** (Puissance Souscrite) et **PSATTEINTE** (Puissance Atteinte) n'étaient **jamais récupérées** depuis les fichiers de factures HT lors de l'import, ce qui laissait ces valeurs à `NaN` dans la Base Centrale.

## ✅ Solutions appliquées

### 1️⃣ **Fichier `import_ht.py`**

#### **A. Configuration étendue**
Ajout des colonnes de puissance dans `CONFIG_HT` :

```python
CONFIG_HT = {
    'cle_facture': 'refraccord',
    'montant_col': 'montfact',
    'conso_col': 'conso',
    'periode_col': 'Periode_Emission_Bordereau',
    'typefact_col': 'typefact',
    'psabon_col': 'PSABON',          # ✨ NOUVEAU
    'psatteinte_col': 'PSATTEINTE'   # ✨ NOUVEAU
}
```

#### **B. Fonction `traiter_factures_e0()` améliorée**
Modification pour cumuler les puissances lors du traitement des factures E0 :

```python
def traiter_factures_e0(df_ht_e0, cle_facture, montant_col, conso_col, 
                        periode_col, psabon_col, psatteinte_col):
    """
    Cumule les montants ET les puissances par IDENTIFIANT
    """
    agg_dict = {
        montant_col: 'sum',
        conso_col: 'sum',
        periode_col: 'first'
    }
    
    # ✨ Ajouter les puissances avec agrégation 'max'
    if psabon_col in df_ht_e0.columns:
        agg_dict[psabon_col] = 'max'
    if psatteinte_col in df_ht_e0.columns:
        agg_dict[psatteinte_col] = 'max'
    
    df_cumul = df_ht_e0.groupby(cle_facture, as_index=False).agg(agg_dict)
    return df_cumul
```

**Logique d'agrégation** : 
- `'max'` pour les puissances car on veut garder la valeur la plus élevée en cas de cumul

#### **C. Mise à jour d'une ligne existante**
Ajout de la récupération des puissances lors de la mise à jour :

```python
if not ligne_existante.empty:
    idx = ligne_existante.index[0]
    df_base_centrale.loc[idx, 'CONSO'] = pd.to_numeric(conso_val, errors='coerce') or 0
    df_base_centrale.loc[idx, 'MONTANT'] = montant
    df_base_centrale.loc[idx, 'DATE_COMPLEMENTAIRE'] = periode if is_e1 else ''
    
    # ✨ NOUVEAU : Récupérer les puissances
    if CONFIG_HT['psabon_col'] in df_traite.columns:
        psabon_val = row_facture.get(CONFIG_HT['psabon_col'], 0)
        df_base_centrale.loc[idx, 'PSABON'] = pd.to_numeric(psabon_val, errors='coerce') or 0
    
    if CONFIG_HT['psatteinte_col'] in df_traite.columns:
        psatteinte_val = row_facture.get(CONFIG_HT['psatteinte_col'], 0)
        df_base_centrale.loc[idx, 'PSATTEINTE'] = pd.to_numeric(psatteinte_val, errors='coerce') or 0
```

#### **D. Création d'une nouvelle ligne**
Ajout des puissances lors de la création d'une nouvelle ligne :

```python
# ✨ Récupérer les puissances depuis la facture
psabon_val = 0
psatteinte_val = 0
if CONFIG_HT['psabon_col'] in df_traite.columns:
    psabon_val = row_facture.get(CONFIG_HT['psabon_col'], 0)
    psabon_val = pd.to_numeric(psabon_val, errors='coerce') or 0

if CONFIG_HT['psatteinte_col'] in df_traite.columns:
    psatteinte_val = row_facture.get(CONFIG_HT['psatteinte_col'], 0)
    psatteinte_val = pd.to_numeric(psatteinte_val, errors='coerce') or 0

nouvelle_ligne = {
    'UC': site_info.get('UC', ''),
    'CODE RED': site_info.get('CODE RED', ''),
    'CODE AGCE': site_info.get('CODE AGCE', ''),
    'SITES': site_info.get('SITES', ''),
    'IDENTIFIANT': identifiant,
    'TENSION': 'HAUTE',
    'DATE': periode,
    'CONSO': pd.to_numeric(conso_val, errors='coerce') or 0,
    'MONTANT': montant,
    'DATE_COMPLEMENTAIRE': periode if is_e1 else '',
    'STATUT': site_info.get('STATUT', 'ACTIF'),
    'PSABON': psabon_val,        # ✨ NOUVEAU
    'PSATTEINTE': psatteinte_val # ✨ NOUVEAU
}
```

### 2️⃣ **Fichier `import_bt.py`**

✅ **Aucune modification nécessaire** - Le fichier initialise déjà correctement les puissances à 0 pour les factures BT :

```python
nouvelle_ligne = {
    # ... autres champs ...
    'PSABON': 0,      # BT n'a pas de puissance
    'PSATTEINTE': 0
}
```

## 🎯 Comportement après correction

### **Pour les factures HT (Haute Tension)**

| Type Facture | PSABON | PSATTEINTE | Comportement |
|--------------|--------|------------|--------------|
| **E0** (Normal) | ✅ Récupéré | ✅ Récupéré | Cumul avec `max()` si plusieurs factures |
| **E1** (Complémentaire) | ✅ Récupéré | ✅ Récupéré | Import manuel, valeurs préservées |
| **E5** (Avoir) | ✅ Récupéré | ✅ Récupéré | Valeurs négatives préservées |
| **Autre** | ✅ Récupéré | ✅ Récupéré | Import normal |

### **Pour les factures BT (Basse Tension)**

| Type Facture | PSABON | PSATTEINTE | Comportement |
|--------------|--------|------------|--------------|
| **Toutes** | `0` | `0` | BT n'a pas de puissance |

## 📊 Impact sur la Base Centrale

Après ces corrections, lors de l'import HT :

1. ✅ Les colonnes **PSABON** et **PSATTEINTE** seront **automatiquement remplies** 
2. ✅ Les valeurs seront **converties en numérique** (gestion des erreurs avec `pd.to_numeric()`)
3. ✅ Les valeurs invalides seront remplacées par **0**
4. ✅ Pour les factures E0 avec cumul, on prend la **valeur maximale** des puissances
5. ✅ Pour les lignes existantes, les puissances seront **mises à jour**

## 🚀 Instructions de déploiement

1. **Remplacer** le fichier `import_ht.py` par la version corrigée
2. **Remplacer** le fichier `import_bt.py` par la version corrigée (optionnel, déjà correct)
3. **Tester** avec un fichier HT contenant les colonnes `PSABON` et `PSATTEINTE`
4. **Vérifier** dans la Base Centrale que les valeurs sont bien remplies

## ✅ Vérifications recommandées

Après import, vérifier dans la Base Centrale :

```python
# Vérifier les puissances HT
df_ht = df_base_centrale[df_base_centrale['TENSION'] == 'HAUTE']
print(f"PSABON non-nulles : {df_ht['PSABON'].notna().sum()} / {len(df_ht)}")
print(f"PSATTEINTE non-nulles : {df_ht['PSATTEINTE'].notna().sum()} / {len(df_ht)}")

# Vérifier les puissances BT (doivent être à 0)
df_bt = df_base_centrale[df_base_centrale['TENSION'] == 'BASSE']
print(f"BT avec PSABON = 0 : {(df_bt['PSABON'] == 0).sum()} / {len(df_bt)}")
```

## 📝 Notes importantes

- Les **noms de colonnes** dans les fichiers HT doivent être exactement `PSABON` et `PSATTEINTE` (sensible à la casse)
- Si ces colonnes sont **absentes** du fichier HT, les valeurs seront initialisées à **0** (pas d'erreur)
- La conversion en numérique utilise `errors='coerce'` pour gérer les valeurs invalides
- Pour BT, les puissances restent toujours à **0** (pas de changement)

---

**Date de correction** : 05/02/2026  
**Fichiers modifiés** : `import_ht.py`  
**Fichiers vérifiés** : `import_bt.py` (déjà correct)
