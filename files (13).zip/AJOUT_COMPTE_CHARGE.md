# 🆕 Ajout de la colonne COMPTE_CHARGE dans la Base Centrale

## 📋 Objectif

Permettre de **gérer dynamiquement** le compte de charges comptable depuis la Base Centrale, au lieu d'avoir une valeur fixe en dur dans le code. Cela permet :

✅ **Flexibilité** : Modifier le compte de charges pour un site spécifique  
✅ **Personnalisation** : Différents sites peuvent avoir différents comptes de charges  
✅ **Traçabilité** : Le compte utilisé est visible dans la base centrale  
✅ **Simplicité** : Plus besoin de modifier le code pour changer un compte  

---

## 🔧 Modifications apportées

### 1️⃣ **Fichier `models.py`**

#### **A. Ajout de la colonne dans COLONNES_BASE_CENTRALE**

```python
COLONNES_BASE_CENTRALE = [
    'UC', 'CODE RED', 'CODE AGCE', 'SITES', 'IDENTIFIANT', 
    'TENSION', 'DATE', 'CONSO', 'MONTANT', 'DATE_COMPLEMENTAIRE', 'STATUT',
    'PSABON', 'PSATTEINTE',  # Puissances HT
    'COMPTE_CHARGE'          # ✨ NOUVEAU : Compte de charges comptable
]
```

#### **B. Initialisation automatique dans `ajouter_lignes_base_centrale()`**

Lors de l'ajout de nouvelles lignes, si COMPTE_CHARGE n'existe pas, il est initialisé à **'62183464'** (valeur par défaut) :

```python
for col in COLONNES_BASE_CENTRALE:
    if col not in df_nouvelles.columns:
        if col == 'STATUT':
            df_nouvelles[col] = 'ACTIF'
        elif col in ['PSABON', 'PSATTEINTE']:
            df_nouvelles[col] = 0
        elif col == 'COMPTE_CHARGE':
            df_nouvelles[col] = '62183464'  # ✨ Compte par défaut
        else:
            df_nouvelles[col] = ''

# Remplir COMPTE_CHARGE si vide
if 'COMPTE_CHARGE' in df_nouvelles.columns:
    df_nouvelles['COMPTE_CHARGE'] = df_nouvelles['COMPTE_CHARGE'].fillna('62183464')
    df_nouvelles['COMPTE_CHARGE'] = df_nouvelles['COMPTE_CHARGE'].replace('', '62183464')
```

#### **C. Modification de `generer_piece_comptable()`**

La fonction utilise maintenant **COMPTE_CHARGE depuis la base centrale** au lieu d'une valeur en dur :

**Avant** :
```python
piece['COMPTE DE CHARGES'] = '62183464'
```

**Après** :
```python
# ✨ Récupérer COMPTE_CHARGE depuis la base centrale
if 'COMPTE_CHARGE' in df_filtre.columns:
    piece['COMPTE DE CHARGES'] = df_filtre['COMPTE_CHARGE'].fillna('62183464')
else:
    piece['COMPTE DE CHARGES'] = '62183464'
```

---

### 2️⃣ **Fichier `import_ht.py`**

#### **Préservation du COMPTE_CHARGE lors de l'import**

Lors de la création d'une nouvelle ligne pour une période, le compte de charges est **préservé depuis le site existant** :

```python
nouvelle_ligne = {
    'UC': site_info.get('UC', ''),
    'CODE RED': site_info.get('CODE RED', ''),
    'CODE AGCE': site_info.get('CODE AGCE', ''),
    'SITES': site_info.get('SITES', ''),
    'IDENTIFIANT': identifiant,
    'TENSION': 'HAUTE',
    'DATE': periode,
    'CONSO': pd.to_numeric(conso_val, errors='coerce') or 0,
    'MONTANT': montant,
    'DATE_COMPLEMENTAIRE': periode if is_e1 else '',
    'STATUT': site_info.get('STATUT', 'ACTIF'),
    'PSABON': psabon_val,
    'PSATTEINTE': psatteinte_val,
    'COMPTE_CHARGE': site_info.get('COMPTE_CHARGE', '62183464')  # ✨ Préserver ou défaut
}
```

---

### 3️⃣ **Fichier `import_bt.py`**

#### **Même logique de préservation**

```python
nouvelle_ligne = {
    # ... autres champs ...
    'COMPTE_CHARGE': site_info.get('COMPTE_CHARGE', '62183464')  # ✨ Préserver ou défaut
}
```

---

## 📊 Structure de la Base Centrale (mise à jour)

| Colonne | Type | Description | Valeur par défaut |
|---------|------|-------------|-------------------|
| UC | Texte | Unité Comptable | '' |
| CODE RED | Texte | Code RED | '' |
| CODE AGCE | Texte | Code Agence | '' |
| SITES | Texte | Nom du site | '' |
| IDENTIFIANT | Texte | Identifiant unique (clé) | '' |
| TENSION | Texte | 'BASSE' ou 'HAUTE' | '' |
| DATE | Texte | Période (MM/YYYY) | '' |
| CONSO | Numérique | Consommation (kWh) | 0 |
| MONTANT | Numérique | Montant TTC | 0 |
| DATE_COMPLEMENTAIRE | Texte | Date facture complémentaire | '' |
| STATUT | Texte | 'ACTIF' ou 'INACTIF' | 'ACTIF' |
| PSABON | Numérique | Puissance souscrite | 0 |
| PSATTEINTE | Numérique | Puissance atteinte | 0 |
| **COMPTE_CHARGE** | **Texte** | **Compte de charges** | **'62183464'** |

---

## 🎯 Utilisation pratique

### **Scénario 1 : Valeur par défaut**

Lors d'un import HT ou BT, si aucune modification n'a été faite :
- **COMPTE_CHARGE** = `'62183464'` (automatique)
- La pièce comptable utilisera ce compte

### **Scénario 2 : Modification manuelle dans la Base Centrale**

Si vous voulez qu'un site utilise un autre compte de charges :

1. **Ouvrir la Base Centrale** (`Base_Centrale.xlsx` ou via l'interface)
2. **Trouver la ligne** du site concerné
3. **Modifier la colonne COMPTE_CHARGE** (par exemple : `'62183999'`)
4. **Sauvegarder**

Lors de la génération de la pièce comptable :
- ✅ Le site utilisera `'62183999'` au lieu de `'62183464'`

### **Scénario 3 : Compte différent par période**

Si un site change de compte de charges à partir d'une certaine période :

1. Les **anciennes lignes** gardent l'ancien compte (ex: `'62183464'`)
2. Les **nouvelles lignes** peuvent avoir le nouveau compte (ex: `'62183999'`)
3. Chaque période garde son propre compte de charges

### **Scénario 4 : Compte différent par TENSION**

- Les sites **BASSE TENSION** peuvent avoir `'62183464'`
- Les sites **HAUTE TENSION** peuvent avoir `'62183777'`
- Chacun garde son propre compte indépendamment

---

## 🔄 Comportement lors de l'import

### **Import d'un nouveau site**
```
Site X n'existe pas dans la base
└─> Créer ligne avec COMPTE_CHARGE = '62183464' (défaut)
```

### **Import d'une nouvelle période pour un site existant**
```
Site X existe déjà avec COMPTE_CHARGE = '62183999'
└─> Nouvelle ligne hérite COMPTE_CHARGE = '62183999' (préservé)
```

### **Import avec modification manuelle préalable**
```
1. Site X a COMPTE_CHARGE = '62183464'
2. Vous modifiez manuellement → COMPTE_CHARGE = '62188888'
3. Import nouvelle période
   └─> Nouvelle ligne hérite COMPTE_CHARGE = '62188888' ✅
```

---

## 🚀 Avantages de cette approche

| Avant | Après |
|-------|-------|
| ❌ Valeur en dur dans le code | ✅ Valeur configurable par site |
| ❌ Modification = changer le code | ✅ Modification = éditer la base |
| ❌ Même compte pour tous | ✅ Comptes différents possibles |
| ❌ Historique impossible | ✅ Historique préservé par période |
| ❌ Nécessite redéploiement | ✅ Effet immédiat |

---

## ⚠️ Points d'attention

### **1. Rétrocompatibilité**
Si votre Base Centrale existante **n'a pas** la colonne COMPTE_CHARGE :
- ✅ Pas de problème : elle sera **créée automatiquement** avec `'62183464'`
- ✅ Les anciennes données seront **migrées** automatiquement

### **2. Format du compte**
- Le compte de charges est un **texte** (string)
- Format typique : `'62183464'` (8 chiffres)
- Peut contenir des lettres si nécessaire : `'6218A001'`

### **3. Valeur vide ou invalide**
Si COMPTE_CHARGE est vide ou manquant :
- ✅ Le système utilise automatiquement `'62183464'` (défaut)
- Pas d'erreur générée

### **4. Modification en masse**
Pour modifier le compte de charges de plusieurs sites :
```python
# Dans l'interface ou via un script
df_base_centrale.loc[
    df_base_centrale['TENSION'] == 'HAUTE', 
    'COMPTE_CHARGE'
] = '62183777'
```

---

## 📝 Exemple de Base Centrale avec COMPTE_CHARGE

| IDENTIFIANT | TENSION | DATE | MONTANT | COMPTE_CHARGE |
|-------------|---------|------|---------|---------------|
| 123456 | HAUTE | 01/2025 | 150000 | 62183464 |
| 123456 | HAUTE | 02/2025 | 145000 | 62183464 |
| 789012 | BASSE | 01/2025 | 25000 | 62183999 |
| 789012 | BASSE | 02/2025 | 27000 | 62183999 |

**Résultat** : Les pièces comptables générées utiliseront les comptes spécifiés pour chaque site.

---

## ✅ Validation

Pour vérifier que tout fonctionne correctement :

```python
# 1. Vérifier que la colonne existe
assert 'COMPTE_CHARGE' in df_base_centrale.columns

# 2. Vérifier qu'il n'y a pas de valeurs vides
valeurs_vides = df_base_centrale['COMPTE_CHARGE'].isna().sum()
print(f"Valeurs vides : {valeurs_vides}")  # Doit être 0

# 3. Vérifier les valeurs uniques
comptes_uniques = df_base_centrale['COMPTE_CHARGE'].unique()
print(f"Comptes de charges utilisés : {comptes_uniques}")

# 4. Générer une pièce comptable test
piece = generer_piece_comptable(df_base_centrale, '01/2025')
print(piece['COMPTE DE CHARGES'].unique())  # Doit correspondre à la base
```

---

## 🎉 Résumé

### **Ce qui change pour vous** :

1. ✅ **Nouvelle colonne** COMPTE_CHARGE dans la Base Centrale
2. ✅ **Valeur par défaut** : `'62183464'` (comme avant)
3. ✅ **Modification possible** : Éditez la base pour changer un compte
4. ✅ **Préservation automatique** : Les imports gardent le compte existant
5. ✅ **Génération dynamique** : Les pièces comptables utilisent le bon compte

### **Ce qui ne change pas** :

- ✅ Si vous ne touchez à rien, tout fonctionne exactement comme avant
- ✅ Le compte par défaut reste `'62183464'`
- ✅ L'import et la génération fonctionnent de la même manière

---

**Date de modification** : 05/02/2026  
**Fichiers modifiés** : `models.py`, `import_ht.py`, `import_bt.py`  
**Fichiers utilisant la modification** : `generation.py` (automatique via `models.py`)
